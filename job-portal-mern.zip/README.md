# Job Portal MERN

Starter full-stack project structure.
